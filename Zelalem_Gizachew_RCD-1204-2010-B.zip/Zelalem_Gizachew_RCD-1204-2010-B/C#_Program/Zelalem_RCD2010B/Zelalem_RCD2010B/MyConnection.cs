﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zelalem_RCD2010B
{
    class MyConnection
    {
        public static SqlConnection con = new SqlConnection(@"Data Source=ZENONYMOUS\SQLEXPRESS;Database=EmployeeDB_Zelalem;Integrated Security=True");

        //public SqlConnection ConnectionOpen()
        //{
        //    SqlConnection con = new SqlConnection(@"Data Source=ZENONYMOUS\SQLEXPRESS;Initial Catalog=EmployeeDB_Zelalem;Integrated Security=True");
        //    try
        //    {
        //        return con;
        //    }
        //    catch (SqlException ex)
        //    {
        //        MessageBox.Show("Here : " + ex.Message);
        //        return null;
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }
        //}
    }
}
