﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zelalem_RCD2010B
{
    public partial class Login_Form : Form
    {
        SqlConnection connection = MyConnection.con;
        public Login_Form()
        {
            InitializeComponent();
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // SqlCommand cmd = new SqlCommand("tblEmployee", connection);
                //connection.Open();

                string username = txtUN.Text;
                string password = txtPW.Text;

                    
                String queryString = "SELECT * FROM tblLogin WHERE userName='" + username + "' AND password='" + password + "'";


                    SqlCommand command = new SqlCommand(queryString, connection);
                    command.Connection.Open();
                    command.ExecuteNonQuery();

                if (command != null)
                {
                    MessageBox.Show("Login sucess Welcome to Homepage");

                    queryString = "SELECT role FROM tblLogin WHERE userName='" + username + "' AND password='" + password + "'";


                    command = new SqlCommand(queryString, connection);
                    command.ExecuteNonQuery();

                    SqlDataReader reader = command.ExecuteReader();
                    Switchboard swi;
                    while (reader.Read())
                    {
                        Console.WriteLine(String.Format("{0}", reader[0]));
                        if (reader[0].ToString() == "user")
                        {
                            swi = new Switchboard("user");
                            swi.Show();
                        }
                        else if (reader[0].ToString() == "admin")
                        {
                            swi = new Switchboard("admin");
                            swi.Show();
                        }
                    }

                    
                    //if (command)
                    //{
                    //    while (sdr.Read())
                    //    {
                    //        //MessageBox.Show(sdr[0].ToString());
                           
                    //    }
                    //}
                }
                else
                {
                    MessageBox.Show("Login Failed 0 " + command);
                }
                

                //SqlDataAdapter sda = new SqlDataAdapter("SELECT COUNT(*) FROM tblLogin WHERE userName='" + username + "' AND password='" + password + "'", connection);
                //DataTable dt = new DataTable();
                //sda.Fill(dt);
                //if (dt.Rows.Count > 0)
                //{
                //    MessageBox.Show("Login sucess Welcome to Homepage");

                //    SqlCommand cmd = new SqlCommand();
                //    cmd.Connection = connection;
                //    cmd.CommandText = "SELECT role FROM tblLogin WHERE userName='" + username + "' AND password='" + password + "'";
                //    cmd.ExecuteNonQuery();

                //    SqlDataReader sdr = cmd.ExecuteReader();
                //    Swithboard swi;
                //    if (sdr.HasRows)
                //    {
                //        while (sdr.Read())
                //        {
                //            //MessageBox.Show(sdr[0].ToString());
                //            if (sdr[0].ToString() == "user")
                //            {
                //                swi = new Swithboard("user");
                //            }
                //            else if (sdr[0].ToString() == "admin")
                //            {
                //                swi = new Swithboard("admin");
                //            }
                //        }
                //    }
                //}
                //else
                //{
                //    MessageBox.Show("Invalid Login please check username and password");
                //}
                connection.Close();
            }
            catch(SqlException sqlEx)
            {
                MessageBox.Show("EXception: " + sqlEx);
            }
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            txtUN.Text = "";
            txtPW.Text = "";
        }
    }
}
