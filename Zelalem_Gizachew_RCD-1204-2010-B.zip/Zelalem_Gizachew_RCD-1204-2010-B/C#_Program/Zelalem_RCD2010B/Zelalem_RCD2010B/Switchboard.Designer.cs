﻿namespace Zelalem_RCD2010B
{
    partial class Switchboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.regEmpBtn = new System.Windows.Forms.Button();
            this.srchEmpBtn = new System.Windows.Forms.Button();
            this.delEmpBtn = new System.Windows.Forms.Button();
            this.updateEmpBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(321, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Switchboard";
            // 
            // regEmpBtn
            // 
            this.regEmpBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regEmpBtn.Location = new System.Drawing.Point(86, 193);
            this.regEmpBtn.Name = "regEmpBtn";
            this.regEmpBtn.Size = new System.Drawing.Size(122, 47);
            this.regEmpBtn.TabIndex = 1;
            this.regEmpBtn.Text = "Register Employee";
            this.regEmpBtn.UseVisualStyleBackColor = true;
            this.regEmpBtn.Click += new System.EventHandler(this.regEmpBtn_Click);
            // 
            // srchEmpBtn
            // 
            this.srchEmpBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.srchEmpBtn.Location = new System.Drawing.Point(214, 193);
            this.srchEmpBtn.Name = "srchEmpBtn";
            this.srchEmpBtn.Size = new System.Drawing.Size(122, 47);
            this.srchEmpBtn.TabIndex = 2;
            this.srchEmpBtn.Text = "Search Employee";
            this.srchEmpBtn.UseVisualStyleBackColor = true;
            this.srchEmpBtn.Click += new System.EventHandler(this.srchEmpBtn_Click);
            // 
            // delEmpBtn
            // 
            this.delEmpBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delEmpBtn.Location = new System.Drawing.Point(342, 193);
            this.delEmpBtn.Name = "delEmpBtn";
            this.delEmpBtn.Size = new System.Drawing.Size(122, 47);
            this.delEmpBtn.TabIndex = 3;
            this.delEmpBtn.Text = "Delete Employee";
            this.delEmpBtn.UseVisualStyleBackColor = true;
            this.delEmpBtn.Click += new System.EventHandler(this.delEmpBtn_Click);
            // 
            // updateEmpBtn
            // 
            this.updateEmpBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateEmpBtn.Location = new System.Drawing.Point(470, 193);
            this.updateEmpBtn.Name = "updateEmpBtn";
            this.updateEmpBtn.Size = new System.Drawing.Size(122, 47);
            this.updateEmpBtn.TabIndex = 4;
            this.updateEmpBtn.Text = "Update Employee";
            this.updateEmpBtn.UseVisualStyleBackColor = true;
            this.updateEmpBtn.Click += new System.EventHandler(this.updateEmpBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitBtn.Location = new System.Drawing.Point(598, 193);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(122, 47);
            this.exitBtn.TabIndex = 5;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // Switchboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(797, 529);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.updateEmpBtn);
            this.Controls.Add(this.delEmpBtn);
            this.Controls.Add(this.srchEmpBtn);
            this.Controls.Add(this.regEmpBtn);
            this.Controls.Add(this.label1);
            this.Name = "Switchboard";
            this.Text = "Swithboard";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button regEmpBtn;
        private System.Windows.Forms.Button srchEmpBtn;
        private System.Windows.Forms.Button delEmpBtn;
        private System.Windows.Forms.Button updateEmpBtn;
        private System.Windows.Forms.Button exitBtn;
    }
}