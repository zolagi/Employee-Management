﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zelalem_RCD2010B
{
    public partial class Finish_Logging_In : Form
    {
        SqlConnection connection = MyConnection.con;
        public static String empName;
        public Finish_Logging_In()
        {
            InitializeComponent();
        }

        private void finishBtn_Click(object sender, EventArgs e)
        {
            // Insert into For Login Table
            SqlCommand cmd1 = new SqlCommand();
            cmd1.Connection = connection;
            var myRole = comboRole.GetItemText(comboRole.SelectedItem);
            cmd1.CommandText = "INSERT INTO tblLogin(userName, password, role) VALUES('" + empName + "','" + txtPass.Text + "','" + myRole.ToString() + "')";
            try
            {
                //connection.Open();
                cmd1.ExecuteNonQuery();
                MessageBox.Show("All the Records have been Added Successfully!");
                connection.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Finish_Logging Error:- " + ex.Message);
            }
            
        }
    }
}
