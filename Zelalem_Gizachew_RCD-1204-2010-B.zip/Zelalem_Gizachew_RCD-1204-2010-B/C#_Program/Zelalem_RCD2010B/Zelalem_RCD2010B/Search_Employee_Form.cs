﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zelalem_RCD2010B
{
    public partial class Search_Employee_Form : Form
    {
        SqlConnection connection = MyConnection.con;
        public Search_Employee_Form()
        {
            InitializeComponent();
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SP_Search_EmployeeDB_Zelalem", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@empID", txtSEmpID.Text);
            try
            {
                connection.Open();
                cmd.ExecuteNonQuery();
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.HasRows)
                {
                    while (sdr.Read())
                    {
                        txtSEmpID.Text = sdr[0].ToString();
                        txtSEmpName.Text = sdr[1].ToString();
                        txtDOB.Text = sdr[2].ToString();
                        txtGender.Text = sdr[3].ToString();
                        txtSEmpAddress.Text = sdr[4].ToString();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Message5:- " + ex.Message);
            }
            connection.Close();
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            txtSEmpID.Text = "";
            txtSEmpName.Text = "";
            txtDOB.Text = "";
            txtGender.Text = "";
            txtSEmpAddress.Text = "";
        }
    }
}
