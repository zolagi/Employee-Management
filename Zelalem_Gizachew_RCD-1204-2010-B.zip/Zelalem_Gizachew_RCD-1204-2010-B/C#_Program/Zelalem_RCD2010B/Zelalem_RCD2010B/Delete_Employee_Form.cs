﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zelalem_RCD2010B
{
    public partial class Delete_Employee_Form : Form
    {
        SqlConnection connection = MyConnection.con;
        public Delete_Employee_Form()
        {
            InitializeComponent();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SP_Delete_EmployeeDB_Zelalem", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@empID", txtDEmpID.Text);
            try
            {
                connection.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("All Rows deleted Successfully!");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Message6:- " + ex.Message);
            }
            connection.Close();
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            txtDEmpID.Text = "";
        }
    }
}
