﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zelalem_RCD2010B
{
    public partial class Employee_Registration_Form : Form
    {
        SqlConnection connection = MyConnection.con;
        public Employee_Registration_Form()
        {
            InitializeComponent();
        }
        
        private void insertBtn_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SP_Insert_EmployeeDB_Zelalem", connection);
            cmd.CommandType = CommandType.StoredProcedure;

            var gender = comboGender.GetItemText(comboGender.SelectedItem);
            cmd.Parameters.AddWithValue("@empID", txtEmpID.Text);
            cmd.Parameters.AddWithValue("@empName", txtEmpName.Text);
            cmd.Parameters.AddWithValue("@empDoB", Convert.ToDateTime(dtpDOB.Text));
            cmd.Parameters.AddWithValue("@empGender", gender);
            cmd.Parameters.AddWithValue("@empAddr", txtEmpAddress.Text);
            
            try
            {
                connection.Open();
                Int32 rowsAffected = cmd.ExecuteNonQuery();
                MessageBox.Show("First_RowsAffected: " + rowsAffected);
                Finish_Logging_In finishup = new Finish_Logging_In();
                Finish_Logging_In.empName = txtEmpName.Text;
                finishup.Show(); // To Add Additional Information on Login Table
            }
            catch (Exception ex)
            {
                Console.WriteLine("Inside_Message1: -" + ex.Message);
            }
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            txtEmpID.Text = "";
            txtEmpName.Text = "";
            dtpDOB.Text = "";
            comboGender.SelectedItem = "";
            txtEmpAddress.Text = "";
        }
    }
}
