﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zelalem_RCD2010B
{
    public partial class Update_Employee_Form : Form
    {
        SqlConnection connection = MyConnection.con;
        public Update_Employee_Form()
        {
            InitializeComponent();
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {

            SqlCommand cmd = new SqlCommand("SP_Update_EmployeeDB_Zelalem", connection);
            cmd.CommandType = CommandType.StoredProcedure;

            var gender = comboUGender.GetItemText(comboUGender.SelectedItem);

            cmd.Parameters.AddWithValue("@empID", txtUEmpID.Text);
            cmd.Parameters.AddWithValue("@empName", txtUEmpName.Text);
            cmd.Parameters.AddWithValue("@empDoB", Convert.ToDateTime(dtpUDOB.Text));
            cmd.Parameters.AddWithValue("@empGender", gender);
            cmd.Parameters.AddWithValue("@empAddr", txtUEmpAddress.Text);
            try
            {
                connection.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("All the Records have been Updated Successfully!");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Me:- " + ex.Message);
            }
            connection.Close();
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {

        }
    }
}
