﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zelalem_RCD2010B
{
    public partial class Switchboard : Form
    {
        Employee_Registration_Form erf;
        Search_Employee_Form ser;
        Delete_Employee_Form delObj;
        Update_Employee_Form updObj;
        public Switchboard()
        {
            InitializeComponent();
        }

        public Switchboard(string role)
        {
            InitializeComponent();

            if (role == "user")
            {
                this.Show();
                srchEmpBtn.Enabled = true;
                regEmpBtn.Enabled = false;
                delEmpBtn.Enabled = false;
                updateEmpBtn.Enabled = false;
            }
            else if (role == "admin")
            {
                //MessageBox.Show("I'm IN!");
                this.Show();
                srchEmpBtn.Enabled = true;
                regEmpBtn.Enabled = true;
                delEmpBtn.Enabled = true;
                updateEmpBtn.Enabled = true;
            }
            else {
                MessageBox.Show("This Shouldn't Be Displayed");
            }
        }

        private void regEmpBtn_Click(object sender, EventArgs e)
        {
            erf = new Employee_Registration_Form();
            erf.Show();
            if (updObj != null)
            {
                updObj.Close();
            }
            if (ser != null)
            {
                ser.Close();
            }
            if (delObj != null)
            {
                delObj.Close();
            }
        }

        private void srchEmpBtn_Click(object sender, EventArgs e)
        {
            ser = new Search_Employee_Form();
            ser.Show();
            if (updObj != null)
            {
                updObj.Close();
            }
            if (erf != null)
            {
                erf.Close();
            }
            if (delObj != null)
            {
                delObj.Close();
            }
        }

        private void delEmpBtn_Click(object sender, EventArgs e)
        {
            delObj = new Delete_Employee_Form();
            delObj.Show();
            if (updObj != null)
            {
                updObj.Close();
            }
            if (ser != null)
            {
                ser.Close();
            }
            if (erf != null)
            {
                erf.Close();
            }
        }

        private void updateEmpBtn_Click(object sender, EventArgs e)
        {
            updObj = new Update_Employee_Form();
            updObj.Show();
            if (erf != null)
            {
                erf.Close();
            }
            if(ser != null)
            {
                ser.Close();
            }
            if (delObj != null)
            {
                delObj.Close();
            }
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
