﻿namespace Zelalem_RCD2010B
{
    partial class Search_Employee_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resetBtn = new System.Windows.Forms.Button();
            this.searcBtn = new System.Windows.Forms.Button();
            this.txtSEmpAddress = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSEmpName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSEmpID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDOB = new System.Windows.Forms.TextBox();
            this.txtGender = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // resetBtn
            // 
            this.resetBtn.Location = new System.Drawing.Point(489, 353);
            this.resetBtn.Name = "resetBtn";
            this.resetBtn.Size = new System.Drawing.Size(75, 32);
            this.resetBtn.TabIndex = 30;
            this.resetBtn.Text = "Reset";
            this.resetBtn.UseVisualStyleBackColor = true;
            this.resetBtn.Click += new System.EventHandler(this.resetBtn_Click);
            // 
            // searcBtn
            // 
            this.searcBtn.Location = new System.Drawing.Point(289, 353);
            this.searcBtn.Name = "searcBtn";
            this.searcBtn.Size = new System.Drawing.Size(75, 32);
            this.searcBtn.TabIndex = 29;
            this.searcBtn.Text = "Search";
            this.searcBtn.UseVisualStyleBackColor = true;
            this.searcBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // txtSEmpAddress
            // 
            this.txtSEmpAddress.Location = new System.Drawing.Point(289, 291);
            this.txtSEmpAddress.Name = "txtSEmpAddress";
            this.txtSEmpAddress.Size = new System.Drawing.Size(314, 20);
            this.txtSEmpAddress.TabIndex = 28;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(122, 298);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 13);
            this.label6.TabIndex = 26;
            this.label6.Text = "Employee Address";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(95, 255);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 13);
            this.label5.TabIndex = 25;
            this.label5.Text = "Employee Date of Birth";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(126, 202);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "Employee Gender";
            // 
            // txtSEmpName
            // 
            this.txtSEmpName.Location = new System.Drawing.Point(289, 159);
            this.txtSEmpName.Name = "txtSEmpName";
            this.txtSEmpName.Size = new System.Drawing.Size(314, 20);
            this.txtSEmpName.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(126, 162);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 21;
            this.label3.Text = "Employee Name";
            // 
            // txtSEmpID
            // 
            this.txtSEmpID.Location = new System.Drawing.Point(289, 113);
            this.txtSEmpID.Name = "txtSEmpID";
            this.txtSEmpID.Size = new System.Drawing.Size(314, 20);
            this.txtSEmpID.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(98, 116);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Employee ID Number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(224, 46);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(340, 20);
            this.label1.TabIndex = 18;
            this.label1.Text = "Search Employee Details by Employee ID";
            // 
            // txtDOB
            // 
            this.txtDOB.Location = new System.Drawing.Point(289, 248);
            this.txtDOB.Name = "txtDOB";
            this.txtDOB.Size = new System.Drawing.Size(314, 20);
            this.txtDOB.TabIndex = 32;
            // 
            // txtGender
            // 
            this.txtGender.Location = new System.Drawing.Point(289, 202);
            this.txtGender.Name = "txtGender";
            this.txtGender.Size = new System.Drawing.Size(314, 20);
            this.txtGender.TabIndex = 31;
            // 
            // Search_Employee_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(910, 529);
            this.Controls.Add(this.txtDOB);
            this.Controls.Add(this.txtGender);
            this.Controls.Add(this.resetBtn);
            this.Controls.Add(this.searcBtn);
            this.Controls.Add(this.txtSEmpAddress);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtSEmpName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSEmpID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Search_Employee_Form";
            this.Text = "Search_Employee_Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button resetBtn;
        private System.Windows.Forms.Button searcBtn;
        private System.Windows.Forms.TextBox txtSEmpAddress;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSEmpName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSEmpID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDOB;
        private System.Windows.Forms.TextBox txtGender;
    }
}